var krms_config ={		
	'ApiUrl':"https://dropp.com.ng/mobileapp/api",			'DialogDefaultTitle':"DROPP",	
	'APIHasKey':"AIzaSyDZhKiMzjGBenelV3oV862slmUOmRicjd8",
     'facebookAppId':"1590850970940899",
	'debug': false
};